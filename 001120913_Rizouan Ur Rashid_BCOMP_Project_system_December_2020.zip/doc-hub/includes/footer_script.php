<!-- password validation -->
<script language='javascript' type='text/javascript'>
	function check(input) {
		if (input.value != document.getElementById('password').value) {
			input.setCustomValidity('Password Must be Matching.');
		} else {
			// input is valid -- reset the error message
			input.setCustomValidity('');
		}
	}
</script>
<!-- Jquery JS -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.0.js"></script>
<!-- Popper JS -->
<script src="js/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="js/bootstrap.min.js"></script>
<!-- Modernizr JS -->
<script src="js/modernizr.min.js"></script>
<!-- ScrollUp JS -->
<script src="js/scrollup.js"></script>
<!-- FacnyBox JS -->
<script src="js/jquery-fancybox.min.js"></script>
<!-- Cube Portfolio JS -->
<script src="js/cubeportfolio.min.js"></script>
<!-- Slick Nav JS -->
<script src="js/slicknav.min.js"></script>
<!-- Slick Nav JS -->
<script src="js/slicknav.min.js"></script>
<!-- Slick Slider JS -->
<script src="js/owl-carousel.min.js"></script>
<!-- Easing JS -->
<script src="js/easing.js"></script>
<!-- Magnipic Popup JS -->
<script src="js/magnific-popup.min.js"></script>
<!-- Active JS -->
<script src="js/active.js"></script>