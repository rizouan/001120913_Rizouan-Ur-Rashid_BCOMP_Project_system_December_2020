<footer class="footer" style="background-image:url('img/map.png')">
	<!-- Footer Top -->
	<div class="footer-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-12">
					<!-- Footer Links -->
					<div class="single-widget f-link widget">
						<h3 class="widget-title">Business Hours</h3>
						<p>Sat - Fri Open 24 hours</p>
					</div>
					<hr>
					<!--/ End Footer Links -->
				</div>
				<div class="col-lg-4 col-md-4 col-12">
					<!-- Footer Links -->
					<div class="single-widget f-link widget">
						<h3 class="widget-title">Location</h3>
						<p>79, Kazi Nazrul Islam Avenue, Farmgate, Dhaka</p>

					</div>
					<hr>
					<!--/ End Footer Links -->
				</div>
				<div class="col-lg-4 col-md-4 col-12">
					<!-- Footer Links -->
					<div class="single-widget f-link widget">
						<h3 class="widget-title">Develop By </h3>
						<p>Name: Rizouan Ur Rashid <strong> | </strong> Greenwitch ID : 001120913</p>

					</div>
					<hr>
					<!--/ End Footer Links -->
				</div>
			</div>
		</div>
	</div>
	<!-- Copyright -->
	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="copyright-content">
						<!-- Copyright Text -->
						<p>© Copyright Doctor's Hub <strong> | </strong> Develop By: Rizouan Ur Rashid <strong> | </strong> Greenwitch ID : 001120913</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--/ End Copyright -->
</footer>